//
//  ServiceRukiApp.swift
//  ServiceRuki
//
//  Created by Эльвира Филиппова on 30.09.2024.
//

import SwiftUI

@main
struct ServiceRukiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView() 
        }
    }
}
